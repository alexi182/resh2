require('../../vendor/jquery.mousewheel.js');
require('../../vendor/mCustomScrollbar.js');

$('.custom-scroll').mCustomScrollbar({
	scrollInertia: 300
 });