require('../../vendor/tooltipster.bundle.js');

$('._tooltip').tooltipster({
    theme: 'tooltipster-light',
    animation: 'fade',
    position: 'bottom',
    delay: 0
});