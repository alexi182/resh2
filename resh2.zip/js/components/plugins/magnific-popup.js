require('../../vendor/jquery.magnific-popup.js');

$('.magnific-popup').magnificPopup({
    type:'image',
    closeOnContentClick: true,
    zoom: {
        enabled: true,
        duration: 300
    }
});