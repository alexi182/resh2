$('body').on('click', function() {
    $('.newsfeed-date-filter__box').removeClass('open');
    $('.news-feed__tomail-box').removeClass('open');
});