/*$('.search_close').on('click', function () {
    var el = $(this),
        search = el.parent('.header__navigation'),
        modal = $('.modal-cover');
        
        search.removeClass('_search-clicked');
        modal.removeClass('_modal-visible');
});*/

